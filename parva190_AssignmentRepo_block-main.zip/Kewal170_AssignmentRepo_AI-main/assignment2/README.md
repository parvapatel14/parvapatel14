Submitting Date: 14/08/2024

Assignment Level: Medium

Code Quality: Maintained

Comments: Added to explain the logic and steps within the code.

Notes
Each function is provided with a brief description at the top.
Code is formatted for readability.
Variable names are chosen to be meaningful.

Steps to Run the Code
1.Install Git, and create your Github account
2.Save the Solidity code with file extension ".sol"
3.Run and compile the code
4.Deploy the code
5.Interact with the Deployed Contract
